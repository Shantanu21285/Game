package com.badlogic.TankStars;

public class Shooter {
}
