package com.badlogic.TankStars;

import com.badlogic.gdx.math.Rectangle;

public class SurfaceTile
{
    private Rectangle Tile;

}
